const express = require("express");
const multer = require("multer");
const fs = require("fs");
const axios = require("axios");
const cors = require("cors");
require("dotenv").config();

const app = express();
const upload = multer({ dest: "uploads/" });

app.use(cors());
app.use(express.static("."));

app.post("/analyze", upload.single("audio"), async (req, res) => {
  try {
    const audioPath = req.file.path;
    const target = req.body.target;

    const response = await axios.post("https://api.openai.com/v1/audio/transcriptions", 
      fs.createReadStream(audioPath),
      {
        headers: {
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "multipart/form-data"
        },
        params: {
          model: "whisper-1",
          language: "ar"
        }
      }
    );

    const text = response.data.text.trim();
    let feedback;

    if (text === target) {
      feedback = "✅ ممتاز! نطقت الحرف بشكل صحيح.";
    } else if (text.includes(target)) {
      feedback = "⚠️ قريب جدًا! حاول تنطق الحرف بدقة أكثر.";
    } else {
      feedback = `❌ لم يتم نطق الحرف بشكل واضح. النص المكتشف: "${text}"`;
    }

    fs.unlinkSync(audioPath);
    res.json({ feedback });
  } catch (error) {
    console.error(error.response?.data || error.message);
    res.status(500).json({ feedback: "حدث خطأ أثناء تحليل الصوت." });
  }
});

const PORT = 3000;
app.listen(PORT, () => console.log(`🎧 الخادم يعمل على http://localhost:${PORT}`));