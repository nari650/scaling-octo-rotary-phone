# تطبيق نطق الحروف بالذكاء الاصطناعي

## المتطلبات:
- Node.js
- حساب OpenAI + مفتاح API

## التشغيل:
1. ضع مفتاح OpenAI في ملف `.env`:
   OPENAI_API_KEY=sk-xxxxxxx

2. شغل الأوامر:
   npm install
   node server.js

3. افتح المتصفح على:
   http://localhost:3000

اختر حرفًا، واضغط تسجيل، وسيتم تقييم نطقك بواسطة Whisper AI.